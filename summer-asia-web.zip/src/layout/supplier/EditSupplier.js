import React from 'react'

export default function EditSupplier() {
  return (
    <div>
      Edit Supplier
    </div>
  )
}
