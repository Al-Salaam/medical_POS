import React from 'react'

export default function EditExpense() {
  return (
    <div>
      Edit Expense
    </div>
  )
}
