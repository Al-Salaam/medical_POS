import React from 'react'

export default function EditCustomer() {
  return (
    <div>
      Edit Customer
    </div>
  )
}
